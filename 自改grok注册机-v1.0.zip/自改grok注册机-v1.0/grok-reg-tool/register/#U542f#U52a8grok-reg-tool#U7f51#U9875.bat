@echo off
chcp 65001 >nul
title Grok Reg Tool

cd /d C:\Users\xiaomingming\grok-reg-tool\grok-reg-tool

echo 正在检查前端...

if not exist "out\renderer\index.html" (
    echo 未发现前端文件，开始构建...
    npm run server:build
)

echo 启动 Web UI...

set PORT=8098

start "" cmd /k "npm run server:start:8098"

timeout /t 3 /nobreak >nul

start "" http://localhost:8098

exit