import express, { type Request, type Response } from 'express';
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import { basename, dirname, join, resolve } from 'node:path';
import { existsSync, promises as fsp } from 'node:fs';
import { WebSocket, WebSocketServer } from 'ws';

import type { RegisterStartArgs, SystemHealth, SystemHealthCheck } from '@shared/ipc';
import type { AppSettings } from '@shared/settings';
import type { RunEvent } from '@shared/runEvents';
import { loadSettings, saveSettings, dataDir } from './settingsStore.js';
import { registerBot } from './bot/registerBot.js';
import { deleteAccountsByIds, getCpaAuthFileForEmail, listAccounts } from './accountStore.js';
import { checkForUpdate, currentVersion } from './updateCheck.js';
import { fetchEmails, extractVerificationCode, fetchLatestCodeByAddress } from './api/emailApi.js';
import { checkSso } from './ssoCheck.js';
import {
  authBootstrapInfo,
  changeCredentials,
  getAuthState,
  getAuthStateFromCookie,
  login,
  logout
} from './authStore.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 6657);
const HOST = process.env.BIND_HOST || '0.0.0.0';
const STATIC_ROOT = resolve(
  process.env.STATIC_ROOT || join(__dirname, '..', '..', '..', '..', 'out', 'renderer')
);

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));

app.use((_req, res, next) => {
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});

async function requireApiAuth(req: Request, res: Response, next: () => void) {
  const state = await getAuthState(req);
  if (state.authenticated) {
    next();
    return;
  }
  res.status(401).json({ error: 'unauthorized' });
}

app.get('/api/auth/me', async (req, res) => {
  res.json(await getAuthState(req));
});

app.post('/api/auth/login', async (req, res) => {
  const state = await login(req, res);
  if (!state) {
    res.status(401).json({ error: '用户名或密码不正确' });
    return;
  }
  res.json(state);
});

app.post('/api/auth/logout', async (req, res) => {
  await logout(req, res);
  res.json({ ok: true });
});

app.post('/api/auth/change', async (req, res) => {
  try {
    res.json(await changeCredentials(req, req.body));
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(message === 'unauthorized' ? 401 : 400).json({ error: message });
  }
});

app.use('/api', requireApiAuth);

app.get('/api/settings', async (_req, res) => {
  res.json(await loadSettings());
});

app.put('/api/settings', async (req: Request, res: Response) => {
  const body = req.body as AppSettings;
  await saveSettings(body);
  res.json({ ok: true });
});

app.get('/api/system/health', async (_req, res) => {
  res.json(await buildSystemHealth());
});

app.get('/api/system/version', (_req, res) => {
  res.json({ current: currentVersion() });
});

app.get('/api/system/update-check', async (_req, res) => {
  res.json(await checkForUpdate());
});

app.get('/api/run/status', async (_req, res) => {
  res.json(registerBot.getStatus());
});

app.post('/api/run/start', async (req: Request, res: Response) => {
  try {
    const args = (req.body ?? {}) as RegisterStartArgs;
    res.json(await registerBot.start({ runCountOverride: args.runCount }));
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/run/stop', async (_req, res) => {
  await registerBot.stop();
  res.json({ ok: true });
});

app.get('/api/accounts', async (_req, res) => {
  res.json(await listAccounts());
});

app.post('/api/accounts/export/grok2api', async (req: Request, res: Response) => {
  const ids = Array.isArray(req.body?.ids) ? new Set(req.body.ids.map((id: unknown) => String(id))) : null;
  const pool = String(req.body?.pool || 'basic').trim() || 'basic';
  const tags = Array.isArray(req.body?.tags)
    ? req.body.tags.map((tag: unknown) => String(tag)).filter(Boolean)
    : ['auto-register', 'grok'];
  const accounts = await listAccounts();
  const targets = (ids ? accounts.filter((account) => ids.has(account.id)) : accounts).filter(
    (account) => account.sso
  );
  const payload = {
    [pool]: targets.map((account) => ({
      token: account.sso,
      tags
    }))
  };
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="grok2api-${Date.now()}.json"`);
  res.send(JSON.stringify(payload, null, 2));
});

app.post('/api/accounts/export/cpa-auth', async (req: Request, res: Response) => {
  const ids = Array.isArray(req.body?.ids) ? new Set(req.body.ids.map((id: unknown) => String(id))) : null;
  const accounts = await listAccounts();
  const targets = ids ? accounts.filter((account) => ids.has(account.id)) : accounts;

  const files: { name: string; data: Buffer }[] = [];
  for (const account of targets) {
    const path = await getCpaAuthFileForEmail(account.email);
    if (!path || !existsSync(path)) continue;
    const safeName = basename(path);
    const data = await fsp.readFile(path);
    files.push({ name: safeName, data });
  }

  if (files.length === 0) {
    res.status(404).json({ error: '未找到可导出的 CPA xAI 认证文件' });
    return;
  }

  if (files.length === 1) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${files[0].name}"`);
    res.send(files[0].data);
    return;
  }

  const zip = buildZip(files);
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="cpa-xai-auth-${Date.now()}.zip"`);
  res.send(zip);
});


app.post('/api/accounts/export/cockpit-auth', async (req: Request, res: Response) => {
  const ids = Array.isArray(req.body?.ids) ? new Set(req.body.ids.map((id: unknown) => String(id))) : null;
  const accounts = await listAccounts();
  const targets = ids ? accounts.filter((account) => ids.has(account.id)) : accounts;

  const files: { name: string; data: Buffer }[] = [];
  for (const account of targets) {
    const path = await getCpaAuthFileForEmail(account.email);
    if (!path || !existsSync(path)) continue;

    try {
      const raw = await fsp.readFile(path, 'utf-8');
      const cpaAuth = JSON.parse(raw) as Record<string, unknown>;
      const cockpitAuth = buildCockpitGrokCliAuth(cpaAuth, account.email);
      const data = Buffer.from(JSON.stringify(cockpitAuth, null, 2), 'utf-8');
      files.push({ name: `auth-${account.email}.json`, data });
    } catch {
      // 单个文件格式异常时跳过，避免影响其他账号导出。
    }
  }

  if (files.length === 0) {
    res.status(404).json({ error: '未找到可转换为 Cockpit/Grok CLI auth.json 的认证文件' });
    return;
  }

  if (files.length === 1) {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${files[0].name}"`);
    res.send(files[0].data);
    return;
  }

  const zip = buildZip(files);
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="cockpit-grok-cli-auth-${Date.now()}.zip"`);
  res.send(zip);
});

app.post('/api/accounts/delete', async (req: Request, res: Response) => {
  const ids = Array.isArray(req.body?.ids) ? req.body.ids.map((id: unknown) => String(id)) : [];
  const deleteCpaAuth = Boolean(req.body?.deleteCpaAuth);
  if (ids.length === 0) {
    res.status(400).json({ error: '缺少要删除的账号 id' });
    return;
  }
  const result = await deleteAccountsByIds(ids, deleteCpaAuth);
  res.json({ ok: true, ...result });
});

app.get('/api/mail/code', async (req: Request, res: Response) => {
  const address = String(req.query.address || '').trim();
  if (!address) {
    res.status(400).json({ error: '缺少邮箱地址' });
    return;
  }
  const settings = await loadSettings();
  const result = await fetchLatestCodeByAddress(
    address,
    { apiBase: settings.mail.apiBase, adminAuth: settings.mail.adminAuth },
    settings.proxy
  );
  res.json(result);
});

app.post('/api/sso/check', async (req: Request, res: Response) => {
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  if (items.length === 0) {
    res.status(400).json({ error: '缺少待验活的 sso 列表' });
    return;
  }
  const settings = await loadSettings();
  const proxy = settings.proxy;

  // 限并发 5，避免对 grok 发起过多并发请求
  const CONCURRENCY = 5;
  const results: unknown[] = [];
  for (let i = 0; i < items.length; i += CONCURRENCY) {
    const batch = items.slice(i, i + CONCURRENCY) as { id: string; sso: string }[];
    const settled = await Promise.all(
      batch.map(async (item) => {
        const outcome = await checkSso(item.sso, proxy);
        return { id: item.id, ...outcome, checkedAt: new Date().toISOString() };
      })
    );
    results.push(...settled);
  }
  res.json({ results });
});

app.post('/api/verify-code', async (req, res) => {
  try {
    const jwt = req.body.jwt;
    if (!jwt) throw new Error("缺少 jwt");
    const settings = await loadSettings();
    if (!settings.mail?.apiBase) throw new Error("缺少邮箱后端地址配置");
    const emails = await fetchEmails(jwt, settings.mail.apiBase, 10);
    let code = null;
    for (const msg of emails) {
      if (msg && msg.raw) {
        code = extractVerificationCode(msg.raw);
        if (code) break;
      }
    }
    res.json({ code: code?.replace('-', '') || null });
  } catch (err) {
    res.status(400).json({ error: (err as Error).message });
  }
});

app.post('/api/test/mail', async (req, res) => {
  try {
    const { apiBase, adminAuth, domain } = req.body;
    if (!apiBase || !adminAuth || !domain) {
      return res.json({ ok: false, message: '缺少邮箱后端配置参数' });
    }
    
    const response = await fetch(`${apiBase}/api/mails?limit=1`, {
      method: 'GET'
    });
    
    if (response.status === 401 || response.status === 200) {
      return res.json({ ok: true, message: '邮箱服务器连接成功' });
    } else {
      return res.json({ ok: false, message: `服务器返回了异常状态码: ${response.status}` });
    }
  } catch (e: any) {
    return res.json({ ok: false, message: `连接失败: ${e.message}` });
  }
});

if (existsSync(STATIC_ROOT)) {
  app.use(express.static(STATIC_ROOT, { index: 'index.html' }));
  app.get(/^\/(?!api).*/, (_req, res) => {
    res.sendFile(join(STATIC_ROOT, 'index.html'));
  });
} else {
  app.get('/', (_req, res) => {
    res
      .status(503)
      .type('text/plain')
      .send(
        `Web UI not built.\nRun \`npm run server:build\` to produce ${STATIC_ROOT}.\nAPI is still online at /api.`
      );
  });
}

const httpServer = createServer(app);
const wss = new WebSocketServer({ noServer: true });
const clients = new Set<WebSocket>();

function sendEvent(ws: WebSocket, event: RunEvent) {
  if (ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify(event));
}

function broadcast(event: RunEvent) {
  for (const ws of clients) {
    sendEvent(ws, event);
  }
}

registerBot.on('event', (event: RunEvent) => {
  broadcast(event);
});

wss.on('connection', (ws) => {
  clients.add(ws);
  for (const event of registerBot.getReplay()) {
    sendEvent(ws, event);
  }
  ws.on('close', () => {
    clients.delete(ws);
  });
});

httpServer.on('upgrade', async (request, socket, head) => {
  const pathname = (() => {
    try {
      return new URL(request.url || '/', 'http://localhost').pathname;
    } catch {
      return '/';
    }
  })();

  if (pathname !== '/ws') {
    socket.destroy();
    return;
  }

  const state = await getAuthStateFromCookie(request.headers.cookie);
  if (!state.authenticated) {
    socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }

  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

httpServer.listen(PORT, HOST, () => {
  console.log(`[grok-reg-tool] listening on http://${HOST}:${PORT}`);
  console.log(`[grok-reg-tool] data dir: ${dataDir()}`);
  console.log(
    `[grok-reg-tool] static UI: ${existsSync(STATIC_ROOT) ? STATIC_ROOT : '(not built)'}`
  );
  void authBootstrapInfo().then((info) => {
    console.log(`[grok-reg-tool] default account: ${info.defaultUsername}`);
    console.log(`[grok-reg-tool] default password: ${info.defaultPassword}`);
    if (info.mustChangePassword) {
      console.log('[grok-reg-tool] first login must change username/password');
    } else {
      console.log(`[grok-reg-tool] web account configured: ${info.username}`);
    }
  });
});


function pickString(source: Record<string, unknown>, keys: string[]): string {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  }
  return '';
}

function toIsoExpiresAt(value: unknown, fallbackExpiresIn?: unknown): string {
  const now = Date.now();

  if (typeof value === 'number' && Number.isFinite(value)) {
    const millis = value > 10_000_000_000 ? value : value * 1000;
    return new Date(millis).toISOString();
  }

  if (typeof value === 'string' && value.trim()) {
    const raw = value.trim();
    if (/^\d+$/.test(raw)) {
      const numeric = Number(raw);
      const millis = numeric > 10_000_000_000 ? numeric : numeric * 1000;
      return new Date(millis).toISOString();
    }
    const parsed = Date.parse(raw);
    if (!Number.isNaN(parsed)) return new Date(parsed).toISOString();
  }

  if (typeof fallbackExpiresIn === 'number' && Number.isFinite(fallbackExpiresIn)) {
    return new Date(now + fallbackExpiresIn * 1000).toISOString();
  }
  if (typeof fallbackExpiresIn === 'string' && /^\d+$/.test(fallbackExpiresIn.trim())) {
    return new Date(now + Number(fallbackExpiresIn.trim()) * 1000).toISOString();
  }

  // 没有过期时间时给一个保守的 7 天后时间，方便 Cockpit/Grok CLI 本地导入识别。
  return new Date(now + 7 * 24 * 60 * 60 * 1000).toISOString();
}

function buildCockpitGrokCliAuth(cpaAuth: Record<string, unknown>, fallbackEmail: string): Record<string, unknown> {
  const accessToken = pickString(cpaAuth, [
    'key',
    'access_token',
    'accessToken',
    'token',
    'api_key',
    'apiKey'
  ]);
  const refreshToken = pickString(cpaAuth, ['refresh_token', 'refreshToken']);
  const email = pickString(cpaAuth, ['email', 'account_email', 'accountEmail', 'username']) || fallbackEmail;
  const expiresAt = toIsoExpiresAt(
    cpaAuth.expires_at ?? cpaAuth.expiresAt ?? cpaAuth.expiry ?? cpaAuth.expired ?? cpaAuth.expires,
    cpaAuth.expires_in ?? cpaAuth.expiresIn
  );

  const entry: Record<string, unknown> = {
    key: accessToken,
    refresh_token: refreshToken,
    expires_at: expiresAt,
    auth_mode: pickString(cpaAuth, ['auth_mode', 'authMode']) || 'xai-grok-cli',
    email,
    team_id: pickString(cpaAuth, ['team_id', 'teamId', 'team']),
    user_id: pickString(cpaAuth, ['user_id', 'userId', 'sub', 'subject']),
    first_name: pickString(cpaAuth, ['first_name', 'firstName', 'given_name', 'givenName']),
    last_name: pickString(cpaAuth, ['last_name', 'lastName', 'family_name', 'familyName'])
  };

  // 保留一些常见元数据，Cockpit 若不需要通常会忽略；若需要则可直接使用。
  for (const [from, to] of [
    ['id_token', 'id_token'],
    ['idToken', 'id_token'],
    ['token_type', 'token_type'],
    ['tokenType', 'token_type'],
    ['scope', 'scope'],
    ['client_id', 'client_id'],
    ['clientId', 'client_id'],
    ['organization_id', 'organization_id'],
    ['organizationId', 'organization_id']
  ] as const) {
    const value = cpaAuth[from];
    if (typeof value === 'string' && value.trim() && entry[to] === undefined) entry[to] = value.trim();
  }

  // 删除空字符串字段，避免某些导入器把空字段当成错误值。
  for (const key of Object.keys(entry)) {
    if (entry[key] === '') delete entry[key];
  }

  return {
    'https://accounts.x.ai/sign-in': entry
  };
}


function crc32(buffer: Buffer): number {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc ^= byte;
    for (let i = 0; i < 8; i += 1) {
      const mask = -(crc & 1);
      crc = (crc >>> 1) ^ (0xedb88320 & mask);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function dosDateTime(date = new Date()): { time: number; date: number } {
  const year = Math.max(1980, date.getFullYear());
  const time = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const dosDate = ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, date: dosDate };
}

function buildZip(files: { name: string; data: Buffer }[]): Buffer {
  const locals: Buffer[] = [];
  const centrals: Buffer[] = [];
  let offset = 0;
  const { time, date } = dosDateTime();

  for (const file of files) {
    const nameBuf = Buffer.from(file.name, 'utf-8');
    const data = file.data;
    const crc = crc32(data);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x0800, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);
    locals.push(local, nameBuf, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(time, 12);
    central.writeUInt16LE(date, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(nameBuf.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(0, 38);
    central.writeUInt32LE(offset, 42);
    centrals.push(central, nameBuf);

    offset += local.length + nameBuf.length + data.length;
  }

  const centralSize = centrals.reduce((sum, part) => sum + part.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);

  return Buffer.concat([...locals, ...centrals, end]);
}

async function buildSystemHealth(): Promise<SystemHealth> {
  const checks: SystemHealthCheck[] = [];
  const pushCheck = (check: SystemHealthCheck) => checks.push(check);

  pushCheck(await checkRegisterScript());
  pushCheck(await checkDataDirWritable());

  const summary = checks.reduce(
    (acc, check) => {
      acc[check.level] += 1;
      acc.total += 1;
      return acc;
    },
    { ok: 0, warn: 0, error: 0, total: 0 }
  );

  return {
    checkedAt: new Date().toISOString(),
    summary,
    checks
  };
}

async function checkRegisterScript(): Promise<SystemHealthCheck> {
  const settings = await loadSettings();
  const registerDir = registerBot.resolveRegisterDir(settings.registerDir);
  const scriptPath = registerDir ? join(registerDir, 'runner.py') : '';
  const legacyScriptPath = registerDir ? join(registerDir, 'DrissionPage_example.py') : '';
  if ((scriptPath && existsSync(scriptPath)) || (legacyScriptPath && existsSync(legacyScriptPath))) {
    return {
      id: 'register-script',
      label: 'Python 注册机',
      level: 'ok',
      message: '注册脚本已就绪',
      detail: existsSync(scriptPath) ? scriptPath : legacyScriptPath
    };
  }
  return {
    id: 'register-script',
    label: 'Python 注册机',
    level: 'warn',
    message: '未找到内置注册脚本，请检查镜像或项目 register/ 目录',
    detail: settings.registerDir || process.env.REGISTER_DIR || '(未配置 registerDir)'
  };
}

async function checkDataDirWritable(): Promise<SystemHealthCheck> {
  const targetDir = dataDir();
  const probeFile = join(targetDir, `.health-${Date.now()}.tmp`);
  try {
    await fsp.mkdir(targetDir, { recursive: true });
    await fsp.writeFile(probeFile, 'ok', 'utf-8');
    await fsp.unlink(probeFile);
    return {
      id: 'data-dir',
      label: '数据目录',
      level: 'ok',
      message: '数据目录可写',
      detail: targetDir
    };
  } catch (err) {
    return {
      id: 'data-dir',
      label: '数据目录',
      level: 'error',
      message: '数据目录不可写',
      detail: err instanceof Error ? err.message : String(err)
    };
  }
}

async function shutdown(sig: string) {
  console.log(`[grok-reg-tool] received ${sig}, stopping...`);
  await registerBot.stop().catch(() => undefined);
  wss.close();
  httpServer.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 8000).unref();
}

process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('SIGTERM', () => void shutdown('SIGTERM'));
