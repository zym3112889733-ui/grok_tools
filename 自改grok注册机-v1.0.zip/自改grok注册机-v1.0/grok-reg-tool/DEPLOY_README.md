# Deployment Package

This package has been cleaned for sharing. Personal accounts, tokens, sessions and local runtime data have been removed.

## Quick start

1. Copy environment examples:

```bash
cp .env.example .env
cp docker/.env.example docker/.env
```

2. Start with Docker:

```bash
cd docker
docker compose up -d --build
```

3. Configure your own account/settings using the provided example configuration files.

Do not copy account/session files from another machine.
