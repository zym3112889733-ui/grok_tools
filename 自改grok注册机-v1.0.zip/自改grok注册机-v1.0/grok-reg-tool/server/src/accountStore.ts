/**
 * 账号记录存储。
 * registerBot 从 Python stdout 关联出 email/password/sso 后追加到这里。
 * 落盘到 <cwd>/out/accounts.json，与 out/sso 同目录；docker 持久化需挂载 out。
 */
import { promises as fsp, existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { basename, join, resolve } from 'node:path';
import type { AccountRecord } from '@shared/runEvents';

function accountsDir(): string {
  return resolve(process.cwd(), 'out');
}

function accountsPath(): string {
  return join(accountsDir(), 'accounts.json');
}


function cpaAuthDir(): string {
  return resolve(process.env.CPA_AUTH_DIR || join(homedir(), '.cli-proxy-api'));
}

function expectedCpaAuthFile(email: string): string {
  return `xai-${email}.json`;
}

async function findCpaAuthFile(email: string): Promise<string | null> {
  const normalizedEmail = String(email || '').trim();
  if (!normalizedEmail) return null;

  const dir = cpaAuthDir();
  const exact = join(dir, expectedCpaAuthFile(normalizedEmail));
  if (existsSync(exact)) return exact;

  try {
    const entries = await fsp.readdir(dir);
    const target = expectedCpaAuthFile(normalizedEmail).toLowerCase();
    const found = entries.find((name) => name.toLowerCase() === target);
    return found ? join(dir, found) : null;
  } catch {
    return null;
  }
}

export async function getCpaAuthFileForEmail(email: string): Promise<string | null> {
  return findCpaAuthFile(email);
}

async function readCpaAuthPreview(authFile: string | null): Promise<Partial<AccountRecord>> {
  if (!authFile || !existsSync(authFile)) return {};
  try {
    const raw = await fsp.readFile(authFile, 'utf-8');
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const accessToken = typeof parsed.access_token === 'string' ? parsed.access_token :
      typeof parsed.accessToken === 'string' ? parsed.accessToken :
      typeof parsed.api_key === 'string' ? parsed.api_key :
      typeof parsed.apiKey === 'string' ? parsed.apiKey : '';
    const refreshToken = typeof parsed.refresh_token === 'string' ? parsed.refresh_token :
      typeof parsed.refreshToken === 'string' ? parsed.refreshToken : '';
    const idToken = typeof parsed.id_token === 'string' ? parsed.id_token :
      typeof parsed.idToken === 'string' ? parsed.idToken : '';
    const expiresAt = typeof parsed.expires_at === 'number' || typeof parsed.expires_at === 'string' ? String(parsed.expires_at) :
      typeof parsed.expiry === 'string' ? parsed.expiry :
      typeof parsed.expired === 'string' ? parsed.expired : '';
    return {
      xaiAccessToken: accessToken || null,
      xaiRefreshToken: refreshToken || null,
      xaiIdToken: idToken || null,
      xaiExpiresAt: expiresAt || null
    };
  } catch {
    return {};
  }
}

async function attachCpaAuthInfo(record: AccountRecord): Promise<AccountRecord> {
  const authFile = await findCpaAuthFile(record.email);
  const preview = await readCpaAuthPreview(authFile);
  return {
    ...record,
    cpaAuthExists: Boolean(authFile),
    cpaAuthFile: authFile ? basename(authFile) : null,
    ...preview
  };
}

async function readAll(): Promise<AccountRecord[]> {
  const path = accountsPath();
  if (!existsSync(path)) return [];
  try {
    const raw = await fsp.readFile(path, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as AccountRecord[]) : [];
  } catch {
    return [];
  }
}

async function writeAll(records: AccountRecord[]): Promise<void> {
  const dir = accountsDir();
  await fsp.mkdir(dir, { recursive: true });
  const path = accountsPath();
  const tmp = `${path}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(records, null, 2), 'utf-8');
  await fsp.rename(tmp, path);
}

export async function appendAccount(record: AccountRecord): Promise<void> {
  const all = await readAll();
  all.push(record);
  await writeAll(all);
}

export async function deleteAccountsByIds(ids: string[], deleteCpaAuth = false): Promise<{ deleted: number; cpaDeleted: number }> {
  const idSet = new Set(ids.map(String));
  const all = await readAll();
  const targets = all.filter((account) => idSet.has(account.id));
  const kept = all.filter((account) => !idSet.has(account.id));

  let cpaDeleted = 0;
  if (deleteCpaAuth) {
    for (const account of targets) {
      const authFile = await findCpaAuthFile(account.email);
      if (authFile && existsSync(authFile)) {
        try {
          await fsp.unlink(authFile);
          cpaDeleted += 1;
        } catch {
          // ignore per-file delete errors
        }
      }
    }
  }

  await writeAll(kept);
  return { deleted: targets.length, cpaDeleted };
}

export async function listAccounts(): Promise<AccountRecord[]> {
  const all = await readAll();
  const sorted = all.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return Promise.all(sorted.map(attachCpaAuthInfo));
}

export async function listRawAccounts(): Promise<AccountRecord[]> {
  return readAll();
}
