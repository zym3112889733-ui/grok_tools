/**
 * 账号记录存储。
 * registerBot 从 Python stdout 关联出 email/password/sso 后追加到这里。
 * 落盘到 <cwd>/out/accounts.json，与 out/sso 同目录；docker 持久化需挂载 out。
 */
import { promises as fsp, existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { basename, join, resolve } from 'node:path';
import type { AccountRecord } from '@shared/runEvents';

function accountsDir(): string {
  return resolve(process.cwd(), 'out');
}

function accountsPath(): string {
  return join(accountsDir(), 'accounts.json');
}


function cpaAuthDir(): string {
  return resolve(process.env.CPA_AUTH_DIR || join(homedir(), '.cli-proxy-api'));
}

function expectedCpaAuthFile(email: string): string {
  return `xai-${email}.json`;
}

async function findCpaAuthFile(email: string): Promise<string | null> {
  const normalizedEmail = String(email || '').trim();
  if (!normalizedEmail) return null;

  const dir = cpaAuthDir();
  const exact = join(dir, expectedCpaAuthFile(normalizedEmail));
  if (existsSync(exact)) return exact;

  try {
    const entries = await fsp.readdir(dir);
    const target = expectedCpaAuthFile(normalizedEmail).toLowerCase();
    const found = entries.find((name) => name.toLowerCase() === target);
    return found ? join(dir, found) : null;
  } catch {
    return null;
  }
}

export async function getCpaAuthFileForEmail(email: string): Promise<string | null> {
  return findCpaAuthFile(email);
}

async function attachCpaAuthInfo(record: AccountRecord): Promise<AccountRecord> {
  const authFile = await findCpaAuthFile(record.email);
  return {
    ...record,
    cpaAuthExists: Boolean(authFile),
    cpaAuthFile: authFile ? basename(authFile) : null
  };
}

async function readAll(): Promise<AccountRecord[]> {
  const path = accountsPath();
  if (!existsSync(path)) return [];
  try {
    const raw = await fsp.readFile(path, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as AccountRecord[]) : [];
  } catch {
    return [];
  }
}

export async function appendAccount(record: AccountRecord): Promise<void> {
  const dir = accountsDir();
  await fsp.mkdir(dir, { recursive: true });
  const all = await readAll();
  all.push(record);
  const path = accountsPath();
  const tmp = `${path}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(all, null, 2), 'utf-8');
  await fsp.rename(tmp, path);
}

export async function listAccounts(): Promise<AccountRecord[]> {
  const all = await readAll();
  const sorted = all.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return Promise.all(sorted.map(attachCpaAuthInfo));
}

export async function listRawAccounts(): Promise<AccountRecord[]> {
  return readAll();
}
